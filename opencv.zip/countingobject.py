from skimage import io, filters
from scipy import ndimage
import matplotlib.pyplot as plt
import cv2

img = cv2.imread('img.png')
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
ret,thresh = cv2.threshold(gray,127,255,1)
contours,h = cv2.findContours(thresh,1,2)
for cnt in contours:
  cv2.drawContours(img,[cnt],0,(0,0,255),1)
