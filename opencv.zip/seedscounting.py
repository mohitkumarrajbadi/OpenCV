from PIL import Image
import numpy as np
import pylab
import matplotlib.cm as cm

calibration_image = Image.open('img.png')
calibration_array = np.array(calibration_image)
calibration_array.shape


pylab.imshow(calibration_array[...,2],)
pylab.colorbar(orientation='horizontal')
pylab.show()
grain_size = np.sum(calibration_array[...,2] < 100) / 21
print(grain_size)
image = Image.open('img.png')
arr = np.array(image)
nseeds = np.sum(arr[...,2] < 100) / grain_size
print(nseeds)
