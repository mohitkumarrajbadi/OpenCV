import cv2
import numpy as np

img = cv2.imread('img.png',cv2.IMREAD_GRAYSCALE)
n_white_pix = np.sum(img == 255)
print('Number of white pixels : ',n_white_pix)
